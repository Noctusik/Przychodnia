﻿namespace Przychodnia
{
    public class Pacjent
    {
        public string Imie { get; set; } = string.Empty;
        public string Nazwisko { get; set; } = string.Empty;
        public string Pesel { get; set; } = string.Empty;
        public string Telefon { get; set; } = string.Empty;
    }
}
